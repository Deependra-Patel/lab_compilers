Lab 1 : Compilers
Team Members:
Anurag Shirolkar
120050003

Deependra Patel
120050032

To run : make

test file contains code for testing.

