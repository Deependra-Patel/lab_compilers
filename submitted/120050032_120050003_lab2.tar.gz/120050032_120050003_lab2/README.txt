Assignment 2
Compilers
Deependra Patel
120050032

Anurag Shirolkar
120050003

To run:
make 
make run