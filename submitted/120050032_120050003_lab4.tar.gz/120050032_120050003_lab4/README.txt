Assignment 4
Compilers
Deependra Patel
120050032

Anurag Shirolkar
120050003

To run:
make

Put the input program in test-assembly
The output/error will be in the file `output.scm` as well as printed at stdout
